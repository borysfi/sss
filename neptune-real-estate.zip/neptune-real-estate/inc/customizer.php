<?php
/**
 * neptune Theme Customizer
 *
 * @package Neptune WP
 */

/**
 * Add postMessage support for site title and description for the Theme Customizer.
 *
 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
 */
function neptune_real_estate_customize_register( $wp_customize ) {
	$wp_customize->get_setting( 'blogname' )->transport         = 'postMessage';
	$wp_customize->get_setting( 'blogdescription' )->transport  = 'postMessage';
	$wp_customize->get_setting( 'header_textcolor' )->transport = 'postMessage';

	if ( isset( $wp_customize->selective_refresh ) ) {
		$wp_customize->selective_refresh->add_partial( 'blogname', array(
			'selector'        => '.site-title a',
			'render_callback' => 'neptune_real_estate_customize_partial_blogname',
		) );
		$wp_customize->selective_refresh->add_partial( 'blogdescription', array(
			'selector'        => '.site-description',
			'render_callback' => 'neptune_real_estate_customize_partial_blogdescription',
		) );
	}
}
add_action( 'customize_register', 'neptune_real_estate_customize_register' );

function neptune_real_estate_sections( $wp_customize ) {
	/**
	 * Add panels
	 */
	$wp_customize->add_panel( 'fonts', array(
		'priority'    => 10,
		'title'       => __( 'Custom Fonts', 'neptune-real-estate' ),
	) );
	$wp_customize->add_panel( 'frontpage', array(
		'priority'    => 1,
		'title'       => __( 'Front Page', 'neptune-real-estate' ),
	) );
	/**
	 * Add sections
	 */
     $wp_customize->add_section( 'body_fonts', array(
 		'title'       => __( 'Body fonts', 'neptune-real-estate' ),
 		'priority'    => 10,
 		'panel'       => 'fonts',
 	) );

     $wp_customize->add_section( 'header_fonts', array(
 		'title'       => __( 'Header fonts', 'neptune-real-estate' ),
 		'priority'    => 10,
 		'panel'       => 'fonts',
 	) );

      $wp_customize->add_section( 'properties', array(
 		'title'       => __( 'Properties', 'neptune-real-estate' ),
 		'priority'    => 2,
 		//'panel'       => 'frontpage',
 		
 	) );  

}


add_action( 'customize_register', 'neptune_real_estate_sections' );

function neptune_real_estate_settings( $wp_customize ) {

if ( class_exists( 'Kirki' ) ) {
		//section one text color
	Kirki::add_field( 'neptune', array(
		'type'        => 'color-palette',
		'settings'    => 'accent_color',
		'label'       => esc_attr__( 'Site Accent Color', 'neptune-real-estate' ),
		'description' => esc_attr__( 'Accent Colors', 'neptune-real-estate' ),
		'section'     => 'colors',
		'default'     => '#2ecc71',
		'choices'     => array(
			'colors' => Kirki_Helper::get_material_design_colors( 'primary' ),
			'size'   => 25,
		),
		'output' => array(
			array(
				'element'  => 'button, a.button,.property-preview .for-sale, .slider-price .more,button, input[type="button"], input[type="reset"], input[type="submit"]',
				'property' => 'background-color',
			),
			array(
				'element'  => 'a.button',
				'property' => 'border-color',
			),
			array(
				'element'  => '.slider-price .more:before',
				'property' => 'border-bottom-color',
			),
			
			array(
				'element'  => '.property-details .location a,.entry-meta a',
				'property' => 'color',
			),
		),
	) );


	kirki::add_field( 'neptune', array(
		'type'     => 'text',
		'settings' => 'currency',
		'label'    => __( 'Property Currency', 'neptune-real-estate' ),
		'section'  => 'properties',
		'priority' => 1,
		'default'  => esc_attr__( '$', 'neptune-real-estate' ),
		'description'    => __( 'Property Price Currency', 'neptune-real-estate' ),

	) );

	/**
	 * Add the body-typography control
	 */
	Kirki::add_field( 'neptune', array(
	    'type'        => 'typography',
	    'settings'    => 'body_typography',
	    'label'       => esc_attr__( 'Body Typography', 'neptune-real-estate' ),
	    'description' => esc_attr__( 'Select the main typography options for your site.', 'neptune-real-estate' ),
	    'help'        => esc_attr__( 'The typography options you set here apply to all content on your site.', 'neptune-real-estate' ),
	    'section'     => 'body_fonts',
	    'priority'    => 10,
	    'default'     => array(
	        'font-family'    => 'Roboto',
	        'variant'        => '400',
	        'font-size'      => '16px',
	        'line-height'    => '1.5',
	        'color'          => '#333333',
	    ),
	    'output' => array(
	        array(
	            'element' => 'body, p',
	        ),
	    ),
	) );

	/**
	 * Add the body-typography control
	 */
	Kirki::add_field( 'neptune', array(
	    'type'        => 'typography',
	    'settings'    => 'headers_typography',
	    'label'       => esc_attr__( 'Headers Typography', 'neptune-real-estate' ),
	    'description' => esc_attr__( 'Select the typography options for your headers.', 'neptune-real-estate' ),
	    'help'        => esc_attr__( 'The typography options you set here will override the Body Typography options for all headers on your site (post titles, widget titles etc).', 'neptune-real-estate' ),
	    'section'     => 'header_fonts',
	    'priority'    => 10,
	    'default'     => array(
	        'font-family'    => 'Oswald',
	    ),
	    'output' => array(
	        array(
	            'element' => array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', '.h1', '.h2', '.h3', '.h4', '.h5', '.h6' ,'.blog-item h2 a, h2.section-title, .property-search input, .property-search select'),
	        ),
	    ),
	) );
}
}
add_action( 'init', 'neptune_real_estate_settings' );
/**
 * Render the site title for the selective refresh partial.
 *
 * @return void
 */
function neptune_real_estate_customize_partial_blogname() {
	bloginfo( 'name' );
}

/**
 * Render the site tagline for the selective refresh partial.
 *
 * @return void
 */
function neptune_real_estate_customize_partial_blogdescription() {
	bloginfo( 'description' );
}

/**
 * Binds JS handlers to make Theme Customizer preview reload changes asynchronously.
 */
function neptune_real_estate_customize_preview_js() {
	wp_enqueue_script( 'neptune-customizer', get_template_directory_uri() . '/js/customizer.js', array( 'customize-preview' ), '20151215', true );
}
add_action( 'customize_preview_init', 'neptune_real_estate_customize_preview_js' );
